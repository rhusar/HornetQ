
public class PlainAOPTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		//FakeInvokerLocatorWithAOP aop = new FakeInvokerLocatorWithAOP();
		//String result = aop.doSomeWork("hell world");
		//System.out.println("result: " + result);
	}

}
