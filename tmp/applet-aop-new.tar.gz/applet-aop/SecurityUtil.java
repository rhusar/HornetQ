import java.security.AccessController;
import java.security.PrivilegedAction;


public class SecurityUtil
{

   // Constants -----------------------------------------------------

   // Attributes ----------------------------------------------------

   // Static --------------------------------------------------------

   // Constructors --------------------------------------------------

   // Public --------------------------------------------------------

   // Package protected ---------------------------------------------
   
   static ClassLoader getTCL()
   {
      if (System.getSecurityManager() != null)
      {
         return Thread.currentThread().getContextClassLoader();
      }
      else
      {
         return AccessController.doPrivileged(new PrivilegedAction<ClassLoader>()
                                              {
                                                 public ClassLoader run()
                                                 {
                                                    return Thread.currentThread().getContextClassLoader();
                                                 }
                                              });
      }
   }

   static void setTCL(final ClassLoader tcl)
   {
      if (System.getSecurityManager() != null)
      {
         Thread.currentThread().setContextClassLoader(tcl);
      }
      else
      {
         AccessController.doPrivileged(new PrivilegedAction<Object>()
                                       {
                                          public Object run()
                                          {
                                             Thread.currentThread().setContextClassLoader(tcl);
                                             return null;
                                          }
                                       });
      }
   }

   // Protected -----------------------------------------------------

   // Private -------------------------------------------------------

   // Inner classes -------------------------------------------------

}
