import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.jboss.aop.AspectManager;
import org.jboss.aop.AspectXmlLoader;
import org.w3c.dom.Document;
import org.xml.sax.EntityResolver;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

public class XMLAopLoader extends AspectXmlLoader
{
   public XMLAopLoader()
   {
      super();
      this.setManager(AspectManager.instance());
   }
   
   /*
    * Deploy aop config from byte[]
    */
   public void deployXML(byte[] config) throws Exception
   {
      
      //We need to synchronized to prevent a deadlock
      //See http://jira.jboss.com/jira/browse/JBMESSAGING-797
      synchronized (AspectManager.instance())
      {         
         InputStream is = null;
         
         try
         {
            is = new ByteArrayInputStream(config);      
         
            DocumentBuilderFactory docBuilderFactory = null;
            
            docBuilderFactory = DocumentBuilderFactory.newInstance();
            
            docBuilderFactory.setValidating(false);
            
            InputSource source = new InputSource(is);
            
            URL url = AspectXmlLoader.class.getResource("/jboss-aop_1_0.dtd");
            
            source.setSystemId(url.toString());
            
            DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
            
            docBuilder.setEntityResolver(new Resolver());
            
            Document doc = docBuilder.parse(source);
            
            this.deployXML(doc, null, this.getClass().getClassLoader());              
         }
         finally
         {
            if (is != null)
            {
               is.close();
            }
         }
      }
   }
   
   /* From AspectXMLLoader.Resolver */
   private static class Resolver implements EntityResolver
   {
      public InputSource resolveEntity(String publicId, String systemId) throws SAXException, IOException
      {
         if (systemId.endsWith("jboss-aop_1_0.dtd"))
         {
            try
            {
               URL url = AspectXmlLoader.class.getResource("/jboss-aop_1_0.dtd");
               InputStream is = url.openStream();
               return new InputSource(is);
            }
            catch (IOException e)
            {
               e.printStackTrace();
               return null;
            }
         }
         return null;
      }
   }
}
