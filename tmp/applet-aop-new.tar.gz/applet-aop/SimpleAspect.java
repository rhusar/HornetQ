import org.jboss.aop.joinpoint.Invocation;


public class SimpleAspect {

	public Object handleDoSomeWork(Invocation inv) throws Throwable
	{
        String res = (String)inv.invokeNext();
        
        res = res + " with AOP";
        
        System.out.println("-----res: " + res);
	    
        return res;
	}

}
