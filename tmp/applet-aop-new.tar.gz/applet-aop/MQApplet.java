
import java.awt.*;
import java.awt.event.*;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.security.AccessController;
import java.security.PrivilegedAction;
import java.util.Hashtable;

import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.JMSException;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.swing.*;

import org.jboss.jms.client.delegate.FakeInvokerLocatorWithAOP;


/**
 * This is a simple chat applet that uses JMS APIs. It uses publish
 * subscribe model. It can also be run as a standalone application.
 */
public class MQApplet extends JApplet
    implements ActionListener {

    private JPanel mainPanel;
    private JTextField addrField;

    JButton connectButton;

    public void init() {
        initGUI();
    }
    

    public void destroy() {
        shutdownGUI();
    }

    private void initGUI() {
        Container content = getContentPane();

        // Create the mainPanel container. It holds all the UI
        // components...
        mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout());
        content.add("Center", mainPanel);

        JPanel dialogPanel = new JPanel();
        dialogPanel.setLayout(
            new BoxLayout(dialogPanel, BoxLayout.Y_AXIS));
        dialogPanel.setBorder(
            createMyBorder("JMS Connection Properties..."));

        JPanel dummyPanel;

        dummyPanel = new JPanel();
        dummyPanel.setLayout(new BoxLayout(dummyPanel, BoxLayout.X_AXIS));
        dummyPanel.add(new JLabel("work to do : "));
        addrField = new JTextField("some work");
        dummyPanel.add(addrField);
        dialogPanel.add(dummyPanel);

        dummyPanel = new JPanel();
        dummyPanel.setLayout(new BoxLayout(dummyPanel, BoxLayout.X_AXIS));

        connectButton = new JButton();
        connectButton.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createEmptyBorder(3, 0, 3, 3),
            connectButton.getBorder()));
        connectButton.addActionListener(this);
        setConnectButton("DoWork");
        dummyPanel.add(connectButton);

        dialogPanel.add(dummyPanel);


        mainPanel.add("North", dialogPanel);
    }


    private void shutdownGUI() {
        remove(mainPanel);
        mainPanel = null;
    }

    public void processEvent(AWTEvent e) {
        if (e.getID() == Event.WINDOW_DESTROY) {
            System.exit(0);
        }
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getActionCommand().equals("DoWork")) {

            try {
				doConnect();
			} catch (IOException e1) {
				e1.printStackTrace();
			} catch (NamingException ed) {
				// TODO Auto-generated catch block
				ed.printStackTrace();
			}
        }
    }
    
    private Frame findParentFrame(){ 
        Container c = this; 
        while(c != null){ 
          if (c instanceof Frame) 
            return (Frame)c; 

          c = c.getParent(); 
        } 
        return (Frame)null; 
      } 

    public void doConnect() throws IOException, NamingException {

    	Hashtable<String, String> env = new Hashtable<String, String>();

		env.put("java.naming.factory.initial",
				"org.jnp.interfaces.NamingContextFactory");
		env.put("java.naming.provider.url", "jnp://localhost:1099");
		env.put("java.naming.factory.url.pkgs",
				"org.jboss.naming:org.jnp.interfaces");

 	    InitialContext ctx = new InitialContext(env);
    	
    	ConnectionFactory factory = (ConnectionFactory)ctx.lookup("/ConnectionFactory");
    	
    	Connection conn = null;
		try {
			conn = factory.createConnection();
		} catch (JMSException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    	System.out.println("conn created: " + conn);
    }
    
    private void showWorkResult(String result)
    {
        Frame f = findParentFrame(); 
        if(f != null){ 
          final Dialog d = new Dialog(f, "modalDialog", true); 
          d.setLayout(new FlowLayout()); 
          d.add(new Label("Result: " + result)); 
          Button bt = new Button("OK");
          bt.addActionListener(new ActionListener() {
        	 public void actionPerformed(ActionEvent e) {
        		 d.setVisible(false);
        		 d.dispose();
        	 }
          });
          d.add(bt);
          d.pack(); 
          d.setLocation(100,100); 
          d.setVisible(true); 
        }     
    }

    private void setConnectButton(String text) {
        connectButton.setText(text);
        connectButton.setActionCommand(text);
        connectButton.invalidate();
        connectButton.validate();
        mainPanel.repaint();
    }

    private javax.swing.border.Border createMyBorder(String title) {
        javax.swing.border.Border inner =
            BorderFactory.createLineBorder(Color.black);

        if (title != null)
            inner = BorderFactory.createTitledBorder(inner, title);

        javax.swing.border.Border outer =
            BorderFactory.createEmptyBorder(3, 3, 3, 3);

        return BorderFactory.createCompoundBorder(outer, inner);
    }

    public void cleanupAndExit() {
        destroy();
        System.exit(0);
    }

    public static MQApplet mq = null;
    public static void mainWindowClosed() {
        mq.cleanupAndExit();
    }

    public static void main(String []args) {
        JFrame f = new JFrame("MQApplet");
        f.setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
        f.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                mainWindowClosed();
            }
        });

        mq = new MQApplet();

        mq.init();
        mq.start();

        f.getContentPane().add("Center", mq);
        f.setSize(600, 600);
        f.setVisible(true);
    }
}


