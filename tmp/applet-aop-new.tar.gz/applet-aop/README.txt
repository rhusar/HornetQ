================================================================================
@(#)README	1.6 03/22/05
================================================================================

JMS Applet example

to build, simple type ant


the applet will be generated into install dir. 


Deploy all files in the install dir to a Web Server


Open a browser from client machine, visit the url that point to your applet deployment




